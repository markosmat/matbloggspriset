 Matbloggspriset Nominera mig! 
-------------
    URI: http://www.matbloggspriset/labbet
    Tags: matbloggspriset, hörnband, band, ribbon, nominera, matbloggar
    Author: Christopher Anderton
    Author URI: http://www.deluxive.se
    Github: https://github.com/Deluxive/matbloggspriset/tree/master/matbloggspriset-nominera-widget
===================

### Installation ###

Se instruktioner.html

#### Skärmdumpar ####
![alt text](https://github.com/Deluxive/matbloggspriset/blob/master/matbloggspriset-nominera-wp/screenshot-1.png?raw=true "Screenshot 1")
![alt text](https://github.com/Deluxive/matbloggspriset/blob/master/matbloggspriset-nominera-wp/screenshot-2.png?raw=true "Screenshot 2")


#### Changelog ####
= 1.0 
- First commit

