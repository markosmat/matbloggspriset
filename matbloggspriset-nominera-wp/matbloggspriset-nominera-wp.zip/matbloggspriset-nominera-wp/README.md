 Matbloggspriset Nominera mig! 
-------------
    URI: http://www.matbloggspriset/labbet
    Tags: matbloggspriset, hörnband, band, ribbon, nominera, matbloggar
    Requires at Least: 2.6.0
    Tested Up To: 3.6.1
    Stable tag: trunk
===================

### Installation ###

1. Ladda ner zipfilen
2. Packa upp den och placera den i `wp-content/plugins` eller ladda upp i WordPress adminpanel under installera tillägg. 
3. Aktivera pluginen.

#### Skärmdumpar ####
![alt text](https://github.com/Deluxive/matbloggspriset/blob/master/matbloggspriset-nominera-wp/screenshot-1.png?raw=true "Screenshot 1")
![alt text](https://github.com/Deluxive/matbloggspriset/blob/master/matbloggspriset-nominera-wp/screenshot-2.png?raw=true "Screenshot 2")


#### Changelog ####
= 1.0 
- Fork från Stop Censorship Ribbon -
http://wordpress.org/plugins/stop-censorship-ribbon/

